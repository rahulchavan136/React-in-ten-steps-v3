import { useState } from "react";
import DepartmentComponent from "./Department";
import TechnologyComponent from "./Technology";


let EmpFormComponent = ({dept,tech ,updateEmpList}) => {
    const [emp , setEmp] = useState({id:'', firstname:"", lastname:"", joindate:"", department:"", technologies:[], projects:''});
    const [isReset,setIsReset] = useState(false);

    const changeEmp = (e) => {
        setEmp({...emp , [e.target.name]:e.target.value});
        isReset(false)
    }

    const changeTech = (tech) => {
        setEmp({...emp , ["technologies"]:tech});
        setIsReset(false)
    }

    const clearEmp = () => {
        setIsReset(true);
        setEmp({id:'', firstname:"", lastname:"", joindate:"", department:"", technologies:[], projects:''})
    }
    
    return (
        <div className="card ms-2">
            <div className="card-header">
                <h3>Employee Form</h3>
            </div>

            <div className="card-body">
                <div className="row g-1 my-1">
                    <div className="col-md-2">
                        <input type="text" className="form-control text-center" placeholder="id" name="id" value={emp.id} onChange={changeEmp}/>
                    </div>
                    <div className="col-md-5">
                        <input type="text" className="form-control text-center" placeholder="first name" name="firstname" value={emp.firstname} onChange={changeEmp}/>
                    </div>
                    <div className="col-md-5">
                        <input type="text" className="form-control text-center" placeholder="last name" name="lastname" value={emp.lastname} onChange={changeEmp}/>
                    </div>
                </div>

                <div className="row g-1 my-1">
                    <div className="col-md-6">
                        <input type="date" className="form-control" name="joindate" value={emp.joindate} onChange={changeEmp}/>
                    </div>

                    <div className="col-md-6">
                        <DepartmentComponent dept={dept} changeDept={changeEmp} isReset={isReset}/>
                    </div>
                </div>

                <div className="row g-1 my-1">
                    <div className="col-md-12">
                        <p className="my-1 text-center">Select Technology</p>
                        <TechnologyComponent tech={tech} changeTech={changeTech} isReset={isReset}/>
                    </div>
                </div>

                <div className="row g-1 my-1">
                    <div className="col-md-6">
                        <p className="my-1 ms-1">Count of Completed Projects</p>
                    </div>

                    <div className="col-md-6">
                        <input type="text" className="form-control text-center" placeholder="count"  name="projects" value={emp.projects} onChange={changeEmp}/>
                    </div>
                </div>

                <div className="row g-1 my-1">
                    <div className="col-md-12">
                        <button className="btn btn-outline-primary float-end" onClick={()=> { updateEmpList(emp); clearEmp();}}>Submit</button>
                    </div>
                </div>
                
            </div>
        </div>
    )
}

export default EmpFormComponent;